package uz.ictschool.personalcontactapp.screens

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.intl.Locale
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.text.isDigitsOnly
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import uz.ictschool.personalcontactapp.database.ContactDataBase
import uz.ictschool.personalcontactapp.database.dataClass.Contact
import uz.ictschool.personalcontactapp.navigation.NavigationRoute

@Composable
fun CreateContact(navController: NavHostController, appDataBase: ContactDataBase){
    val name = remember {
        mutableStateOf("")
    }
    val sureName = remember {
        mutableStateOf("")
    }
    val phoneNumber = remember {
        mutableStateOf("")
    }
    Scaffold (
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars),
        topBar = {
            Row (modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween){
                Row (verticalAlignment = Alignment.CenterVertically){
                    IconButton(onClick = {
                        navController.navigate(NavigationRoute.AllContacts.route)
                    }){
                        Icon(Icons.Default.KeyboardArrowLeft, null, modifier = Modifier.size(30.dp))
                    }
                    Text("Create Contact", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                }
                IconButton(onClick = {
                    /*Create Contact*/
                    if(isValid(name = name.value, phoneNumber.value)){
                        appDataBase.getContactsDao().addContact(
                            Contact(
                                firstName = name.value,
                                lastName = sureName.value,
                                phoneNumber = phoneNumber.value
                            )
                        )
                        navController.navigate(NavigationRoute.AllContacts.route)
                    }
                }) {
                    Icon(Icons.Default.Check, null)
                }
            }
        }
    ){ padding ->
        Column (modifier = Modifier
            .fillMaxSize()
            .padding(padding),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally){
            IconButton(onClick = {
                /*TODO: Upload Contact Image*/
            },
                modifier = Modifier.size(200.dp)){
                Icon(Icons.Default.AccountCircle, null, modifier = Modifier.fillMaxSize())
            }
            OutlinedTextField(
                value = name.value,
                onValueChange = {
                    name.value=it
                },
                modifier = Modifier
                    .padding(vertical = 8.dp, horizontal = 16.dp)
                    .clickable {
                        navController.navigate(NavigationRoute.AllContacts.route)
                    },
                shape = RoundedCornerShape(20.dp),
                colors = TextFieldDefaults.colors(
                    unfocusedContainerColor = Color.White,
                    focusedContainerColor = Color.White
                ),
                placeholder = { Text("Jack", color = Color.Gray)},
                label = { Text("Name")}
            )

            OutlinedTextField(
                value = sureName.value,
                onValueChange = {
                    sureName.value = it
                },
                modifier = Modifier
                    .padding(vertical = 8.dp, horizontal = 16.dp)
                    .clickable {
                        navController.navigate(NavigationRoute.AllContacts.route)
                    },
                shape = RoundedCornerShape(20.dp),
                colors = TextFieldDefaults.colors(
                    unfocusedContainerColor = Color.White,
                    focusedContainerColor = Color.White
                ),
                placeholder = { Text("London", color = Color.Gray)},
                label = { Text("Surename")}
            )
            OutlinedTextField(
                value = phoneNumber.value,
                onValueChange = {
                    phoneNumber.value=it
                },
                modifier = Modifier
                    .padding(vertical = 8.dp, horizontal = 16.dp)
                    .clickable {
                        navController.navigate(NavigationRoute.AllContacts.route)
                    },
                shape = RoundedCornerShape(20.dp),
                colors = TextFieldDefaults.colors(
                    unfocusedContainerColor = Color.White,
                    focusedContainerColor = Color.White
                ),
                placeholder = { Text("+998 94 894 12 33", color = Color.Gray)},
                label = { Text("Phone number")}
            )
        }
    }
}

fun isValid(name: String, phone: String): Boolean {
    if (name.isEmpty() || phone.isEmpty()) {
        return false
    }

    if (phone.length != 13) {
        return false
    }

    if (!phone.startsWith("+998")) {
        return false
    }

    if (!phone.substring(1).isDigitsOnly()) {
        return false
    }


    return true

}

@Composable
@Preview(showSystemUi = true)
fun prev(){
    CreateContact(rememberNavController(), ContactDataBase.getInstance(LocalContext.current))
}