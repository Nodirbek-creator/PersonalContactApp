package uz.ictschool.personalcontactapp.screens.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
fun PhoneKeyBoard(showKeyboard:MutableState<Boolean>, phoneNumber:MutableState<String>) {
    if(showKeyboard.value){
        Dialog(
            onDismissRequest = {
                showKeyboard.value = false
            },)
        {
            Column(
                modifier = Modifier.fillMaxWidth().fillMaxHeight(0.5f).background(MaterialTheme.colorScheme.background)
            ){
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color.White),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    IconButton(
                        onClick = {
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            null,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = phoneNumber.value,
                        textAlign = TextAlign.Center,
                        fontSize = 24.sp,
                        modifier = Modifier.fillMaxWidth(0.5f)
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            phoneNumber.value = phoneNumber.value.dropLast(1)
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            null,
                            modifier = Modifier.size(48.dp)
                        )
                    }

                }
                Spacer(Modifier.height(6.dp))
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.Center
                ) {
                    Row (
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center){
                        CallButton("1", "%") {phoneNumber.value += "1"}
                        CallButton("2", "ABC") {phoneNumber.value += "2" }
                        CallButton("3", "DEF") {phoneNumber.value += "3"}
                    }
                    Spacer(Modifier.height(6.dp))
                    Row (
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center) {
                        CallButton("4", "GHI") {phoneNumber.value += "4" }
                        CallButton("5", "JKL") {phoneNumber.value += "5" }
                        CallButton("6", "MNO") {phoneNumber.value += "6" }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row (
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center){
                        CallButton("7", "PQRS") {phoneNumber.value += "7" }
                        CallButton("8", "TUV") {phoneNumber.value += "8" }
                        CallButton("9", "XYZ") {phoneNumber.value += "9" }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row (
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center){
                        CallButton("*", "") {phoneNumber.value += "*" }
                        CallButton("0", "+") {phoneNumber.value += "0" }
                        CallButton("#", "") {phoneNumber.value += "#" }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Button(
                        onClick = {

                        },
                        shape = RoundedCornerShape(32.dp),
                        modifier = Modifier.fillMaxWidth(0.4f).height(60.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Green
                        )
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ){
                            Icon(
                                imageVector = Icons.Default.Call,
                                null,
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Call",
                                color = Color.White,
                                )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CallButton(
    title:String,
    subTitle:String,
    onClick:() -> Unit
){
    Button(
        onClick = { onClick() },
        shape = RoundedCornerShape(32.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.White
        ),
        modifier = Modifier.width(100.dp).height(60.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = Color.Black,
                fontSize = 20.sp,
            )
            Text(
                text = subTitle,
                fontSize = 12.sp,
                color = Color.DarkGray
            )
        }
    }
}