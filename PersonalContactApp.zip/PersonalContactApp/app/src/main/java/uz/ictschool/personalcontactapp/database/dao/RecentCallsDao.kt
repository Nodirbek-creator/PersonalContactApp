package uz.ictschool.personalcontactapp.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import uz.ictschool.personalcontactapp.database.dataClass.RecentCall

@Dao
interface RecentCallsDao {

    @Query("SELECT * FROM recent_calls")
    fun getAllRecentCalls():List<RecentCall>

    @Query("SELECT * FROM recent_calls WHERE id = :id")
    fun getRecentCallById(id:Int): RecentCall?

    @Query("SELECT * FROM recent_calls WHERE phone_number = :phoneNumber")
    fun getRecentCallsByNumber(phoneNumber:String):List<RecentCall>?

    @Query("DELETE FROM recent_calls WHERE id = :id")
    fun deleteRecentCallById(id: Int)

    @Query("DELETE FROM recent_calls WHERE phone_number = :phoneNumber")
    fun deleteAllRecentCallsByPhoneNumber(phoneNumber:String)

    @Insert
    fun addRecentCall(recentCall: RecentCall)

    /* Learn how to work with device's real time&date.
    TODO:As you learn this get these functions out of the comments.*/

//    @Query("SELECT * FROM recent_calls WHERE date = :date")
//    fun getAllCallsByDate(date:String):List<RecentCall>?
}
