package uz.ictschool.personalcontactapp.database.dataClass

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recent_calls")
data class RecentCall(
    @PrimaryKey(autoGenerate = true)
    val id:Int = 0,

    @ColumnInfo(name = "first_name")
    val firstName:String? = null,
    @ColumnInfo(name = "last_name")
    val lastName:String? = null,
    @ColumnInfo(name = "phone_number")
    val phoneNumber:String,
    val date:String, /*Date format: {Month:Day:Hour:Minute}*/
)