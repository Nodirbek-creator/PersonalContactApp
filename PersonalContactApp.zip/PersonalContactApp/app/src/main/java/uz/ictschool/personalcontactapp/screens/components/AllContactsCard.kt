package uz.ictschool.personalcontactapp.screens.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.ictschool.personalcontactapp.database.dataClass.Contact

@Composable
fun AllContactsCard(contact: Contact) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val fullName = "${contact.firstName} ${contact.lastName}"
        Icon(
            imageVector = Icons.Default.AccountCircle,
            contentDescription = "photo",
            modifier = Modifier.size(64.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = if(fullName.length<25){
                fullName
            }
            else{
                fullName.substring(0..25)
            },
            fontSize = 20.sp,
            color = Color.Black
        )
    }
}