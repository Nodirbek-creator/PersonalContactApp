package uz.ictschool.personalcontactapp.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import uz.ictschool.personalcontactapp.database.dataClass.Contact

@Dao
interface ContactsDao {

    @Query("SELECT * FROM my_contacts")
    fun getAllContacts():List<Contact>

    @Query("SELECT * FROM my_contacts WHERE id = :id")
    fun getContactById(id:Int): Contact?

    @Query("SELECT * FROM my_contacts WHERE is_favorite = 1")
    fun getAllFavoriteContacts():List<Contact>
    /* I'm not really sure
     if this should be nullable. TODO:Consult with teacher!*/


    @Query("DELETE FROM my_contacts WHERE id = :id")
    fun deleteContactById(id: Int)

    @Insert
    fun addContact(myContact: Contact)
}