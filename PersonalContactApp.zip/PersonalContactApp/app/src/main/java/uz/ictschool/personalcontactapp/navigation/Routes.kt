package uz.ictschool.personalcontactapp.navigation

enum class Screens {
    FAVORITE_CONTACTS,
    SPLASH_SCREEN,
    RECENT_CALLS,
    ALL_CONTACTS,
    CONTACT_DETAILS,
    CREATE_CONTACT,
    CALL_MENU,

}

sealed class NavigationRoute(val route:String){
    /* 3 main screens. startDestination = RecentCalls*/
    data object FavoriteContacts: NavigationRoute(Screens.FAVORITE_CONTACTS.name)
    data object RecentCalls: NavigationRoute(Screens.RECENT_CALLS.name)
    data object AllContacts: NavigationRoute(Screens.ALL_CONTACTS.name)

    /*qo'shimcha screenlar.*/
    data object ContactDetails: NavigationRoute(Screens.CONTACT_DETAILS.name)
    data object CreateContact: NavigationRoute(Screens.CREATE_CONTACT.name)
    data object CallMenu: NavigationRoute(Screens.CALL_MENU.name)
    data object SplashScreen: NavigationRoute(Screens.SPLASH_SCREEN.name)

}
