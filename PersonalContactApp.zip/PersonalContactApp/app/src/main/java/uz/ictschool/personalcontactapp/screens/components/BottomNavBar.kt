package uz.ictschool.personalcontactapp.screens.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import uz.ictschool.personalcontactapp.navigation.NavigationRoute


//Icon for Bottom Navigation Bar
data class BottomNavItem(
    val title:String,
    val selectedIcon:ImageVector,
    val unSelectedIcon:ImageVector,
    val hasNews:Boolean? = null,
    val route:String
)


@Composable
fun BottomNavBar(navController:NavHostController){

    //bottom icons' list. here are 3 icons: Favorite, Recent, and Contacts.
    val bottomIcons = listOf(
        BottomNavItem(
            title = "Favorite",
            selectedIcon = Icons.Filled.Favorite,
            unSelectedIcon = Icons.Outlined.FavoriteBorder,
            route = NavigationRoute.FavoriteContacts.route
        ),
        BottomNavItem(
            title = "Recents",
            selectedIcon = Icons.Filled.Home,
            unSelectedIcon = Icons.Outlined.Home,
            route = NavigationRoute.RecentCalls.route,
            hasNews = true,

        ),
        BottomNavItem(
            title = "Contacts",
            selectedIcon = Icons.Filled.Person,
            unSelectedIcon = Icons.Outlined.Person,
            route = NavigationRoute.AllContacts.route,

        ),
    )
    /*Line of code that gets the current route of the app*/
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar {
        bottomIcons.forEachIndexed { _, bottomNavItem ->
            NavigationBarItem(
                selected =  currentRoute == bottomNavItem.route,
                onClick = {
                    navController.navigate(bottomNavItem.route)
                },
                icon = {
                    BadgedBox(
                        badge = {
                            if(bottomNavItem.hasNews == true){
                                Badge()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if(currentRoute == bottomNavItem.route) bottomNavItem.selectedIcon
                            else bottomNavItem.unSelectedIcon,
                            contentDescription = bottomNavItem.title
                        )
                    }
                },
                label = {
                    Text(bottomNavItem.title)
                }
            )
        }
    }
}