package uz.ictschool.personalcontactapp.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.rememberLottieComposition
import uz.ictschool.personalcontactapp.R
import uz.ictschool.personalcontactapp.database.ContactDataBase
import uz.ictschool.personalcontactapp.navigation.NavigationRoute
import uz.ictschool.personalcontactapp.screens.components.AllContactsCard
import uz.ictschool.personalcontactapp.screens.components.BottomNavBar
import uz.ictschool.personalcontactapp.ui.theme.myBlue

@Composable
fun AllContacts(navController: NavHostController, appDataBase: ContactDataBase) {

    //lottie animation
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.empty_box))

    val allContactsList = appDataBase.getContactsDao().getAllContacts()

    Scaffold(
        modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars),
        topBar = {
            TopBarTextField(navController)
        },
        bottomBar = {
            BottomNavBar(navController)
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    navController.navigate(NavigationRoute.CreateContact.route)
                },
                containerColor = myBlue
            ) {
                Icon(imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = Color.White)
            }
        }
    ) { padding ->
        if(allContactsList.isEmpty()){
            Column (
                modifier = Modifier.fillMaxSize().background(Color.White).padding(padding),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ){
                LottieAnimation(
                    composition = composition,
                    isPlaying = true,
                    modifier = Modifier.size(400.dp))
                Text(
                    text = "You have no contacts yet",
                    color = Color.Gray,
                    fontSize = 20.sp)
            }
        }
        else{
            Column(
                modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LazyColumn (
                    modifier = Modifier.fillMaxSize().padding(padding),
                    horizontalAlignment = Alignment.CenterHorizontally
                ){
                    items (allContactsList){
                        AllContactsCard(it)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }

}