package uz.ictschool.personalcontactapp.database.dataClass

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "my_contacts")
data class Contact(

    @PrimaryKey(autoGenerate = true)
    val id:Int = 0, /* reason for specifying id = 0 is for OOP related stuff.
    This id's value won't affect the id in the Data Base.
    It's just for not declaring the same variable over and over again*/

    val firstName:String,
    val lastName:String?,
    val img:String? = null,

    @ColumnInfo(name = "is_favorite")
    val isFavorite:Boolean = false,
    /*we set Column Info because the column's name should not be in Camel case.
     Snake case is preferred in databases.*/
    @ColumnInfo(name = "phone_number")
    val phoneNumber:String,
)