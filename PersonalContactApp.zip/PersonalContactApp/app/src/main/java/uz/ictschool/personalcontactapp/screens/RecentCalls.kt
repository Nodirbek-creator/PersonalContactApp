package uz.ictschool.personalcontactapp.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.rememberLottieComposition
import uz.ictschool.personalcontactapp.database.dataClass.Contact
import com.example.indiecontactapp.screens.components.RecentCallCard
import uz.ictschool.personalcontactapp.R
import uz.ictschool.personalcontactapp.database.ContactDataBase
import uz.ictschool.personalcontactapp.navigation.NavigationRoute
import uz.ictschool.personalcontactapp.screens.components.BottomNavBar
import uz.ictschool.personalcontactapp.screens.components.PhoneKeyBoard
import uz.ictschool.personalcontactapp.ui.theme.myBlue
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun TopBarTextField(navController: NavHostController){
    var searchInput by rememberSaveable {
        mutableStateOf("")
    }
    TextField(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp,horizontal = 16.dp).clickable {
            navController.navigate(NavigationRoute.AllContacts.route)
        },
        shape = RoundedCornerShape(32.dp),
        colors = TextFieldDefaults.colors(
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent
        ),
        value = searchInput,
        onValueChange = {
            searchInput = it
        },
        placeholder = {
            Text("Search contacts",
                color = Color.Gray,
                fontSize = 16.sp)
        },
        leadingIcon = {
            IconButton(
                onClick = {
                    /*TODO: Move to the different screen*/
                    navController.navigate(NavigationRoute.AllContacts.route)
                },
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                )
            }
        },
        trailingIcon = {
            Row {
                IconButton(
                    onClick = {
                        /*TODO: Enable Voice to Text function from Google*/
                    },
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        null,
                    )
                }
                IconButton(
                    onClick = {
                        /*TODO: Enable DropDown Menu.
                           Menu has 2 contents: Call History and Settings(move to the Settings Screen)*/
                    },
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        null,
                    )
                }
            }
        }
    )
}


@Composable
fun RecentCalls(navController: NavHostController, appDataBase:ContactDataBase){

    //lottie animation
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.empty_box))

    //Initializing RecentCallsDao
    val recentCallsDao = appDataBase.getCallHistoryDao()

    //Boolean variables
    var floatingBtnClicked by remember { mutableStateOf(false) }
    var showKeyboard = remember { mutableStateOf(false) }
    var phoneInput = remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopBarTextField(navController)
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    floatingBtnClicked = !floatingBtnClicked
                },
                containerColor = myBlue)
            {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Add",
                    tint = Color.White)
            }
        },
        bottomBar = {
            BottomNavBar(navController)
        },
        modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (recentCallsDao.getAllRecentCalls().isEmpty()) {
                //Empty Screen
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    LottieAnimation(
                        composition = composition,
                        isPlaying = true,
                        modifier = Modifier.size(400.dp)
                    )
                    Text(
                        text = "You have no calls yet",
                        color = Color.Gray,
                        fontSize = 20.sp
                    )
                }
            }
            if(floatingBtnClicked){
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Bottom,
                ){
                    showKeyboard.value = true
                    if(showKeyboard.value){
                        PhoneKeyBoard(
                            showKeyboard,
                            phoneInput
                        )
                    }
                }
            }
            else {
                //Full Contacts List

                /*Based on recent calls history there will be 3 categories:
                    1. Today
                    2. Yesterday
                    3. Older
                 TODO: Learn how to work with Date class!*/

                val currentDateTime = LocalDateTime.now()
                val formattedDateForUser =
                    currentDateTime.format(DateTimeFormatter.ofPattern("MMMM dd, HH:mm"))
                val formattedDateForChecking =
                    currentDateTime.format(DateTimeFormatter.ofPattern("MMMM dd"))


                Spacer(modifier = Modifier.height(16.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text(
                            text = "Older",
                            fontSize = 18.sp,
                            modifier = Modifier.fillMaxWidth().padding(start = 12.dp),
                            textAlign = TextAlign.Start,
                            color = Color.DarkGray
                        )
                        recentCallsDao.getAllRecentCalls().forEach { contact ->
                            RecentCallCard(contact)
                        }
                    }

                }
            }
        }
    }
}

@Composable
@Preview(showSystemUi = true)
fun PreviewRecentScreen(){
    RecentCalls(rememberNavController(), ContactDataBase.getInstance(LocalContext.current))
}