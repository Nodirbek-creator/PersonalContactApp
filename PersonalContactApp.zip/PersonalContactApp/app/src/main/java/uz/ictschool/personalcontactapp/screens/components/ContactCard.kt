package com.example.indiecontactapp.screens.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.ictschool.personalcontactapp.database.dataClass.Contact

@Composable
fun ContactCard(
    contact: Contact
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
       verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ){
        val fullName = "${contact.firstName} ${contact.lastName}"
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ){
            Box(
                modifier = Modifier.size(56.dp),
                contentAlignment = Alignment.Center
            ){
                Image(
                    /*Enable image setting in your app*/
                    imageVector = Icons.Default.AccountCircle,
                    contentDescription = "photo",
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop

                )
            }
            Column (
                modifier = Modifier.width(180.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ){
                Text(
                    text = if(fullName.length>17){
                        "${fullName.substring(0,17)}..."
                    }
                    else{
                        fullName
                    },
                    fontSize = 16.sp
                )
                Text(
                    text = contact.phoneNumber,
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
        }
        Icon(
            imageVector = Icons.Default.Call,
            contentDescription = "call",
            tint = Color(0xFF08AE2D),
            modifier = Modifier.clickable {

            },)
    }
}

@Preview(showBackground = true)
@Composable
fun DisplayCard(){
    ContactCard(contact = Contact(1, "Muhammadali", "Eshonqulov", "", phoneNumber =  "+998 93 399 12 15"))
}