package uz.ictschool.personalcontactapp.screens


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.rememberLottieComposition
import com.airbnb.lottie.compose.LottieCompositionSpec
import kotlinx.coroutines.delay
import uz.ictschool.personalcontactapp.R
import uz.ictschool.personalcontactapp.navigation.NavigationRoute

@Composable
fun SplashScreen(navController: NavController) {
    val composition by rememberLottieComposition(LottieCompositionSpec.RawRes(R.raw.splash_screen))

    Column(
        modifier = Modifier.fillMaxSize().background(Color.White).windowInsetsPadding(WindowInsets.systemBars),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        LottieAnimation(
            composition = composition,
            isPlaying = true,
            restartOnPlay = true,
            modifier = Modifier.size(400.dp))
    }
    LaunchedEffect(Unit) {
        delay(750)
        navController.navigate(NavigationRoute.RecentCalls.route) {
            popUpTo(NavigationRoute.SplashScreen.route) { inclusive = true }
        }
    }
}
@Composable
@Preview(showSystemUi = true)
fun prevspl(){
    SplashScreen(rememberNavController())
}