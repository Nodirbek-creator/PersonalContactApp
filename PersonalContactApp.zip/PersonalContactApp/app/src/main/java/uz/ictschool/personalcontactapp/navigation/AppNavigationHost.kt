package uz.ictschool.personalcontactapp.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import uz.ictschool.personalcontactapp.screens.RecentCalls
import uz.ictschool.personalcontactapp.database.dataClass.Contact
import uz.ictschool.personalcontactapp.screens.AllContacts
import uz.ictschool.personalcontactapp.screens.FavoriteContacts

@Composable
fun AppNavigationHost(
    modifier:Modifier,
    navController: NavHostController,
    startDestination: String = Screens.RECENT_CALLS.name
){
    NavHost(
        modifier = modifier,
        navController = navController,
        startDestination = startDestination
    ){
        composable(NavigationRoute.RecentCalls.route){
            //Code for MainScreen
            RecentCalls(contactsList = listOf(
                Contact(firstName =  "Muhammadali", lastName = "Eshonqulov",img = "", phoneNumber = "+998 93 399 12 15"),
                Contact(firstName = "Nodirbek", lastName = "Baxromov",img =  "", phoneNumber =  "+998 93 814 12 15"),
            ), navController)
        }

        composable(NavigationRoute.AllContacts.route) {
            AllContacts(navController)
        }

        composable(NavigationRoute.FavoriteContacts.route) {
            FavoriteContacts(navController)
        }

        composable(NavigationRoute.ContactDetails.route){
            //Code for DetailsScreen
        }

        composable(NavigationRoute.AddContact.route){
            //Code for AddContactScreen
        }


    }

}