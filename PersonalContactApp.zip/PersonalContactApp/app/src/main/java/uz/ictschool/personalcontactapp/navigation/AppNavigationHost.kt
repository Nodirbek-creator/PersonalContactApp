package uz.ictschool.personalcontactapp.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import uz.ictschool.personalcontactapp.database.ContactDataBase
import uz.ictschool.personalcontactapp.screens.RecentCalls
import uz.ictschool.personalcontactapp.database.dataClass.Contact
import uz.ictschool.personalcontactapp.screens.AllContacts
import uz.ictschool.personalcontactapp.screens.CreateContact
import uz.ictschool.personalcontactapp.screens.FavoriteContacts
import uz.ictschool.personalcontactapp.screens.SplashScreen

@Composable
fun AppNavigationHost(
    modifier:Modifier,
    navController: NavHostController,
    startDestination: String = Screens.SPLASH_SCREEN.name,
    appDataBase:ContactDataBase
){
    NavHost(
        modifier = modifier,
        navController = navController,
        startDestination = startDestination
    ){
        composable(NavigationRoute.RecentCalls.route){
            //Code for MainScreen
            RecentCalls(navController, appDataBase = appDataBase)
        }

        composable(NavigationRoute.AllContacts.route) {
            AllContacts(navController, appDataBase = appDataBase)
        }

        composable(NavigationRoute.FavoriteContacts.route) {
            FavoriteContacts(navController)
        }

        composable(NavigationRoute.SplashScreen.route){
            SplashScreen(navController)
        }

        composable(NavigationRoute.ContactDetails.route){
            //Code for DetailsScreen
        }

        composable(NavigationRoute.CreateContact.route){
            //Code for AddContactScreen
            CreateContact(navController, appDataBase)
        }



    }

}